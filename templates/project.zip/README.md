# cli-template

## 功能介绍
1. 易于使用的cli模板
2. 帮助你快速高效的开发cli工具   

## 安装
```
yarn
```

## 开发时运行   
```
node run start   
node run demo 
// ... others 
```
 
