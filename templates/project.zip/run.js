require('ts-node/register')
// process.chdir('') // fake your cwd
require('./src')
     //tsconfig 帮助文档地址
     //https://zhongsp.gitbooks.io/typescript-handbook/content/doc/handbook/tsconfig.json.html
     //https://tslang.cn/docs/handbook/compiler-options.html