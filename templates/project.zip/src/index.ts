import * as path from 'path'
import { start } from 'cli-parent'

start(path.join(__dirname, './commands'))